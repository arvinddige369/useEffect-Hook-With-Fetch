import React, { useEffect, useState }  from 'react'

export default function Demo() {
    const [productId, setProductId] = useState("");
const [productData, setProductData] = useState(null);

useEffect(() =>{
  if(productId){
    fetch(`https://dummyjson.com/products/${productId}`)
    .then(Response => Response.json())
    .then(data => setProductData(data))
    .catch(error => console.log('error Feching Data', error))
  }
},[productId])

const handleProductIdChange = event => {
  setProductId(event.target.value);
};

  return (
    <div>
    <label htmlFor='productId'>Enter product is:</label>
    <input type='text' value={productId} id='productId' onChange={handleProductIdChange}/>
    {productData ? (
     <div>
     <h2>Product details</h2>
     <p>ID:{productData.id}</p>
     <p>Title: {productData.title}</p>
     <p>Des{productData.description}</p>
     </div>
    ): ( <p> Enter a product id to fech data</p> )}
    </div>
  )
}
