import React, { useEffect, useState } from 'react'

export default function NewDemo() {
const[users, setUsers] = useState("");

useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(Response => Response.json())
    .then(data => setUsers(data))
    .catch(error => console.log("fech deta error", error))
},[]);

if (!users) {
  return <div>Loading...</div>;
}
  return (
  <div>
  <h2>user details</h2>
    {users.map(({id, name, username, email})=>(
    <div key={id}>
    <h3>User Id: {id}</h3>
    <h4>Name: {name}</h4>
    <h4>Username: {username}</h4>
    <h4>Email: {email}</h4>
    </div>
))}
</div>
  )
}
