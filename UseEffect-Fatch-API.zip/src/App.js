import React, { useEffect, useState } from 'react';
import './App.css';
import Demo from './componant/Demo';
import NewDemo from './componant/NewDemo';


function App() {
  const [count, setCount] = useState(0);
  const [name, setName] = useState('');

  useEffect(() => {
    console.log("count was change", count, name);
    // document.title = `You Click ${count}`
  },[count,name])

  


  return (
    <div className="App">
    <h2> {count}</h2>
    <h2>{`count was change, ${count},${name}`}</h2>
    <button onClick={() => setCount(count + 1)}>Click me</button>
    <input type='text' value={name} onChange={e => setName(e.target.value)}/>
    <br/> <br/>
    <Demo/>
    <NewDemo/>
    </div>
    
  );
}

export default App;
